public class IterativeTraverse<T extends Comparable<T>> extends Traverser<T>{
    public IterativeTraverse(){
        //TODO: Implement the function
    };
    
    public IterativeTraverse(SelfOrderingList<T> list){
        //TODO: Implement the function
    }

    @Override
    public SelfOrderingList<T> reverseList() {
        //TODO: Implement the function
    }

    @Override
    public boolean contains(T data) {
        //TODO: Implement the function
    }

    @Override
    public String toString() {
        //TODO: Implement the function
    }

    @Override
    public Node<T> get(int pos) {
        //TODO: Implement the function
    }

    @Override
    public Node<T> find(T data) {
        //TODO: Implement the function
    }

    @Override
    public int size() {
        //TODO: Implement the function
    }

    @Override
    public SelfOrderingList<T> clone(SelfOrderingList<T> otherList) {
        //TODO: Implement the function
    }
}
