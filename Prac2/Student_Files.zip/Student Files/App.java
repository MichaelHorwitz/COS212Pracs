public class App {
    public static void main(String[] args) throws Exception {
        //TODO: Implement an extensive testing main!!!
    }

}
